function showError(input, message) 
{
    const errorSpan = document.querySelector(`span.error[for="${input.id}"]`);
    errorSpan.textContent = message;
}
function clearErrors() 
{
    document.querySelectorAll('.error').forEach(function(el) {
        el.textContent = '';
    });
}
function validateEmail(email) 
{
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
}
function isValid(form) 
{
    let email = form.email.value.trim();
    let password = form.password.value.trim();
    let isValid = true;

    clearErrors();

    if (!email) 
        {
        showError(form.email, 'Email is required.');
        isValid = false;
    } else if (!validateEmail(email)) {
        showError(form.email, 'Invalid email format.');
        isValid = false;
    }

    if (!password) {
        showError(form.password, 'Password is required.');
        isValid = false;
    }

    return isValid;
}

document.getElementById('forgotPasswordForm').addEventListener('submit', function(event) 
{
    const email = this.email.value.trim();
    clearErrors();

    if (!email) {
        showError(this.email, 'Email is required.');
        event.preventDefault();
    } else if (!validateEmail(email)) {
        showError(this.email, 'Please enter a valid email address.');
        event.preventDefault();
    }
});

document.getElementById('registrationForm').addEventListener('submit', function(event) 
{
    let isValid = true;
    const form = this;

    clearErrors();

    const name = form.name.value.trim();
    const studentId = form.student_id.value.trim();
    const email = form.email.value.trim();
    const password = form.password.value.trim();

    if (!name) 
        {
        showError(form.name, 'Full Name is required.');
        isValid = false;
    }

    const studentIdPattern = /^(00|22)-\d{5}-[1-3]$/;
    if (!studentIdPattern.test(studentId)) 
        {
        showError(form.student_id, 'Student ID must follow the correct format (e.g., 22-00000-1).');
        isValid = false;
    }

    if (!email) 
        {
        showError(form.email, 'Email is required.');
        isValid = false;
    } else if (!validateEmail(email)) 
        {
        showError(form.email, 'Email is invalid.');
        isValid = false;
    }

    if (!password) 
        {
        showError(form.password, 'Password is required.');
        isValid = false;
    }

    if (!isValid) 
        {
        event.preventDefault();
    }
});
