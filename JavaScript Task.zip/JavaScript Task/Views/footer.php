<script src="../../../Assets/JS/script.js">
</script>
<footer>
<p>&copy; <?php echo date('Y'); ?> Image Drive. All rights reserved.</p>
</footer>
</body>
</html>
