SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE TABLE `photos` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `photos` (`id`, `user_id`, `filename`) VALUES
(12, 1, 'uploads/66e1d6777bc8a_FREE-HDconvert.com3a3b68c26dd6da0cf21492f40d6fcac5.jpg'),
(13, 1, 'uploads/66e1d68184c23_FREE-HDconvert.com3a3b68c26dd6da0cf21492f40d6fcac5-min.jpg'),
(14, 1, 'uploads/66e1d7316f26b_Screenshot2024-04-25223404.jpg');

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'bortoman', '$2y$10$HLdNaYlkbuc76MzSyEmVOuqwCohKgu.N1TRerisq.Le6kueHCelmG'),
(2, 'bot', '$2y$10$1DUpZnDnW4yERwFVDL.53OI7dNzvWbtfGZ5BrG1PrBOl7FJ/gl53O');

ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

ALTER TABLE `photos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `photos`
  ADD CONSTRAINT `photos_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;
