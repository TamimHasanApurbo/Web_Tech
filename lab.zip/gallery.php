<?php

session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$error = "";
$success = "";

$target_dir = __DIR__ . DIRECTORY_SEPARATOR . "uploads" . DIRECTORY_SEPARATOR;

if (!file_exists($target_dir)) {
    mkdir($target_dir, 0777, true);
}

if (!is_writable($target_dir)) {
    die("Error: Upload directory is not writable. Please check permissions.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['photo'])) {
    $file_name = preg_replace('/[^a-zA-Z0-9\._-]/', '', basename($_FILES["photo"]["name"]));
    $target_file = $target_dir . uniqid() . "_" . $file_name; // Unique file name to avoid collisions
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    
    
    $check = getimagesize($_FILES["photo"]["tmp_name"]);
    if ($check !== false) {
        $uploadOk = 1;
    } else {
        $error = "File is not an image.";
        $uploadOk = 0;
    }

    $max_file_size = 5 * 1024 * 1024; 
    if ($_FILES["photo"]["size"] > $max_file_size) {
        $error = "Sorry, your file is too large. Maximum file size is 5MB.";
        $uploadOk = 0;
    }
   
    $allowed_formats = ["jpg", "jpeg", "png", "gif"];
    if (!in_array($imageFileType, $allowed_formats)) {
        $error = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }


    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
            $db_filename = "uploads/" . basename($target_file); 
            $sql = "INSERT INTO photos (user_id, filename) VALUES (?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "is", $user_id, $db_filename);
            
            if (mysqli_stmt_execute($stmt)) {
                $success = "The file " . basename($_FILES["photo"]["name"]) . " has been uploaded.";
                
                header("Location: my_gallery.php?success=" . urlencode($success));
                exit();
            } else {
                $error = "Sorry, there was an error uploading your file to the database.";
            }
        } else {
            $error = "Sorry, there was an error uploading your file to the server. Error: " . error_get_last()['message'];
        }
    }
}


if (!empty($error)) {
    header("Location: my_gallery.php?error=" . urlencode($error));
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Photo</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Upload Photo</h2>
        <form action="gallery.php" method="post" enctype="multipart/form-data"novalidate>
            <input type="file" name="photo" required>
            <button type="submit">Upload Photo</button>
        </form>
        <a href="my_gallery.php">Go to My Photo Gallery</a>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>