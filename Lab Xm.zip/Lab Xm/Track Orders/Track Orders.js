function trackOrder() {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "track_order.php", true);
    xhr.onload = function() {
