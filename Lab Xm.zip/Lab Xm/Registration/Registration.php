<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];
    $password = $_POST['password'];

    if (!preg_match("/^[a-zA-Z ]+$/", $name)) {
        die("Invalid name format");
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format");
    }
    if (!preg_match("/^[0-9]{10}$/", $phone)) {
        die("Invalid phone number");
    }

    $passwordHash = password_hash($password, PASSWORD_BCRYPT);

    $_SESSION['user'] = ['name' => $name, 'email' => $email, 'phone' => $phone];

    echo "Registration successful!";
}
?>